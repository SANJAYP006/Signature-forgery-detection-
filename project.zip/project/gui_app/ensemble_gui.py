# gui_app/ensemble_gui.py
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk, ImageDraw, ImageFilter
import numpy as np
import joblib
from tensorflow.keras.models import load_model

# Import utils
import sys
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")
MODELS_DIR = os.path.join(BASE_DIR, "models")
if SCRIPTS_DIR not in sys.path:
    sys.path.append(SCRIPTS_DIR)

from utils import preprocess_for_cnn, extract_handcrafted

# Try mailing
try:
    import mailing
    HAS_MAILING = True
except:
    HAS_MAILING = False

WEIGHTS = {"cnn_a": 1.0, "cnn_b": 1.0, "svm": 0.8, "rf": 0.8}

class Ensemble:
    def __init__(self):
        self.cnn_a = self._load_h5("cnn_a.h5")
        self.cnn_b = self._load_h5("cnn_b.h5")
        self.svm = self._load_joblib("svm_hog_lbp.joblib")
        self.rf  = self._load_joblib("rf_hog_lbp.joblib")
        self.scaler = self._load_joblib("scaler.joblib")
        self.stacker = self._load_joblib("stacker.joblib")

    def _load_h5(self, name):
        path = os.path.join(MODELS_DIR, name)
        return load_model(path) if os.path.exists(path) else None

    def _load_joblib(self, name):
        path = os.path.join(MODELS_DIR, name)
        return joblib.load(path) if os.path.exists(path) else None

    def predict(self, pil_img):
        cnn_img, bin_img = preprocess_for_cnn(pil_img)
        probs = {}

        # CNN A
        if self.cnn_a:
            p = self.cnn_a.predict(np.expand_dims(cnn_img, 0), verbose=0)[0]
            probs["cnn_a"] = float(p[1])
        # CNN B
        if self.cnn_b:
            p = self.cnn_b.predict(np.expand_dims(cnn_img, 0), verbose=0)[0]
            probs["cnn_b"] = float(p[1])

        # Classical
        if (self.svm or self.rf):
            feats = extract_handcrafted(bin_img).reshape(1,-1)
            if self.scaler: feats = self.scaler.transform(feats)
            if self.svm: probs["svm"] = float(self.svm.predict_proba(feats)[0,1])
            if self.rf:  probs["rf"]  = float(self.rf.predict_proba(feats)[0,1])

        # Ensemble
        order = [k for k in ["cnn_a","cnn_b","svm","rf"] if k in probs]
        base = np.array([probs[k] for k in order]).reshape(1,-1)
        if self.stacker is not None and base.shape[1] >= 2:
            try:
                final_prob = float(self.stacker.predict_proba(base)[0,1])
            except:
                final_prob = float(np.clip(self.stacker.predict(base)[0], 0.0, 1.0))
        else:
            num=0.0; den=0.0
            for k,v in probs.items():
                w = WEIGHTS.get(k,1.0)
                num+=w*v; den+=w
            final_prob = num/max(den,1e-8)

        label = 1 if final_prob >= 0.5 else 0
        return probs, final_prob, label

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Signature Verification - Desktop Application")
        self.root.configure(bg='#1a1a2e')
        self.ens = Ensemble()
        self.pil = None
        self.filepath = None
        
        # Configure modern styling
        self.setup_styles()
        
        # Create gradient background
        self.create_gradient_background()
        
        # Create main container
        self.create_main_interface()
    
    def setup_styles(self):
        """Setup modern styling for the application"""
        style = ttk.Style()
        
        # Configure modern button style
        style.theme_use('clam')
        style.configure('Modern.TButton',
                       background='#667eea',
                       foreground='white',
                       borderwidth=0,
                       focuscolor='none',
                       font=('Inter', 11, 'bold'))
        style.map('Modern.TButton',
                 background=[('active', '#764ba2'),
                           ('pressed', '#5a67d8')])
    
    def create_gradient_background(self):
        """Create a modern gradient background"""
        self.canvas = tk.Canvas(self.root, width=1200, height=800, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        
        # Create gradient effect
        gradient = Image.new('RGB', (1200, 800), '#1a1a2e')
        draw = ImageDraw.Draw(gradient)
        
        # Create gradient from top to bottom
        for i in range(800):
            # Interpolate between colors
            r = int(26 + (102 - 26) * (i / 800))
            g = int(26 + (126 - 26) * (i / 800))
            b = int(46 + (234 - 46) * (i / 800))
            draw.line([(0, i), (1200, i)], fill=(r, g, b))
        
        # Add some blur for smoothness
        gradient = gradient.filter(ImageFilter.GaussianBlur(radius=2))
        
        self.bg_photo = ImageTk.PhotoImage(gradient)
        self.canvas.create_image(0, 0, anchor="nw", image=self.bg_photo)
    
    def create_main_interface(self):
        """Create the main interface elements"""
        # Main container frame with modern styling
        main_frame = tk.Frame(self.root, bg='#ffffff', bd=0, relief='flat')
        main_frame.place(relx=0.5, rely=0.5, anchor='center', width=600, height=500)
        
        # Add rounded corners effect (simulated with border)
        main_frame.configure(highlightbackground='#e2e8f0', highlightthickness=1)
        
        # Header section
        header_frame = tk.Frame(main_frame, bg='#ffffff', height=80)
        header_frame.pack(fill='x', pady=(20, 10))
        header_frame.pack_propagate(False)

        # Modern header with icon
        icon_label = tk.Label(header_frame, text="🛡️", font=("Arial", 24), bg='#ffffff')
        icon_label.pack(pady=(10, 5))
        
        title_label = tk.Label(header_frame, 
                              text="AI Signature Verification", 
                              font=("Inter", 18, "bold"), 
                              fg='#2d3748', 
                              bg='#ffffff')
        title_label.pack()
        
        subtitle_label = tk.Label(header_frame, 
                                 text="Advanced fraud detection using ensemble machine learning", 
                                 font=("Inter", 10), 
                                 fg='#718096', 
                                 bg='#ffffff')
        subtitle_label.pack()

        # Email input section
        email_frame = tk.Frame(main_frame, bg='#ffffff')
        email_frame.pack(fill='x', padx=40, pady=10)
        
        email_label = tk.Label(email_frame, 
                              text="📧 NOTIFICATION EMAIL", 
                              font=("Inter", 10, "bold"), 
                              fg='#4a5568', 
                              bg='#ffffff')
        email_label.pack(anchor='w', pady=(0, 5))
        
        self.email = tk.Entry(email_frame, 
                             font=("Inter", 11), 
                             bg='#f7fafc', 
                             fg='#2d3748',
                             bd=2,
                             relief='solid',
                             highlightthickness=1,
                             highlightcolor='#667eea')
        self.email.pack(fill='x', ipady=8)
        self.email.insert(0, "Enter your email address")
        self.email.bind('<FocusIn>', self.on_email_focus_in)
        self.email.bind('<FocusOut>', self.on_email_focus_out)

        # Button section
        button_frame = tk.Frame(main_frame, bg='#ffffff')
        button_frame.pack(fill='x', padx=40, pady=20)
        
        # Modern styled buttons
        btn_style = {
            'font': ('Inter', 11, 'bold'),
            'bg': '#667eea',
            'fg': 'white',
            'bd': 0,
            'relief': 'flat',
            'cursor': 'hand2',
            'padx': 20,
            'pady': 10
        }
        
        browse_btn = tk.Button(button_frame, 
                              text="📁 Browse Image", 
                              command=self.pick,
                              **btn_style)
        browse_btn.pack(side='left', padx=(0, 10), fill='x', expand=True)
        
        analyze_btn = tk.Button(button_frame, 
                               text="🔍 Analyze Signature", 
                               command=self.run,
                               bg='#764ba2',
                               **{k: v for k, v in btn_style.items() if k != 'bg'})
        analyze_btn.pack(side='right', padx=(10, 0), fill='x', expand=True)
        
        # Bind hover effects
        self.bind_hover_effects(browse_btn, '#5a67d8', '#667eea')
        self.bind_hover_effects(analyze_btn, '#6b46c1', '#764ba2')

        # Preview section
        preview_frame = tk.Frame(main_frame, bg='#f8f9fa', relief='solid', bd=1)
        preview_frame.pack(fill='both', expand=True, padx=40, pady=(10, 20))
        
        preview_label = tk.Label(preview_frame, 
                                text="📄 IMAGE PREVIEW", 
                                font=("Inter", 10, "bold"), 
                                fg='#4a5568', 
                                bg='#f8f9fa')
        preview_label.pack(pady=(10, 5))
        
        self.preview = tk.Label(preview_frame, 
                               text="No image selected", 
                               font=("Inter", 12), 
                               fg='#a0aec0', 
                               bg='#f8f9fa')
        self.preview.pack(expand=True)

        # Results section (initially hidden)
        self.results_frame = tk.Frame(self.root, bg='#ffffff', bd=1, relief='solid')
        
        results_header = tk.Label(self.results_frame, 
                                 text="📊 ANALYSIS RESULTS", 
                                 font=("Inter", 12, "bold"), 
                                 fg='#2d3748', 
                                 bg='#ffffff')
        results_header.pack(pady=(15, 10))
        
        self.result = tk.Label(self.results_frame, 
                              text="", 
                              font=("Inter", 14, "bold"), 
                              bg='#ffffff')
        self.result.pack(pady=5)
        
        self.detail = tk.Label(self.results_frame, 
                              text="", 
                              font=("Consolas", 9), 
                              justify="left", 
                              bg='#f8f9fa',
                              fg='#4a5568')
        self.detail.pack(pady=10, padx=20, fill='x')
    
    def bind_hover_effects(self, button, hover_color, normal_color):
        """Add hover effects to buttons"""
        def on_enter(e):
            button.configure(bg=hover_color)
        
        def on_leave(e):
            button.configure(bg=normal_color)
        
        button.bind('<Enter>', on_enter)
        button.bind('<Leave>', on_leave)
    
    def on_email_focus_in(self, event):
        """Handle email field focus in"""
        if self.email.get() == "Enter your email address":
            self.email.delete(0, tk.END)
            self.email.configure(fg='#2d3748')
    
    def on_email_focus_out(self, event):
        """Handle email field focus out"""
        if not self.email.get():
            self.email.insert(0, "Enter your email address")
            self.email.configure(fg='#a0aec0')

    def pick(self):
        path = filedialog.askopenfilename(
            title="Select Signature Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.bmp *.gif"),
                      ("PNG files", "*.png"),
                      ("JPEG files", "*.jpg *.jpeg"),
                      ("All files", "*.*")]
        )
        if not path: return
        
        self.filepath = path
        self.pil = Image.open(path).convert("RGB")
        
        # Create thumbnail with better quality
        thumb = self.pil.copy()
        thumb.thumbnail((300, 200), Image.Resampling.LANCZOS)
        
        # Add border to thumbnail
        bordered_thumb = Image.new('RGB', (thumb.width + 4, thumb.height + 4), '#e2e8f0')
        bordered_thumb.paste(thumb, (2, 2))
        
        tkimg = ImageTk.PhotoImage(bordered_thumb)
        self.preview.config(image=tkimg, text="")
        self.preview.image = tkimg
        
        # Show filename
        filename = os.path.basename(path)
        if len(filename) > 30:
            filename = filename[:27] + "..."
        
        filename_label = tk.Label(self.preview.master, 
                                 text=f"📁 {filename}", 
                                 font=("Inter", 9), 
                                 fg='#4a5568', 
                                 bg='#f8f9fa')
        filename_label.pack(pady=(5, 0))

    def run(self):
        if self.pil is None:
            messagebox.showwarning("⚠️ Warning", "Please select an image first.")
            return
        
        # Show loading state
        self.show_loading()
        
        try:
            probs, final_prob, label = self.ens.predict(self.pil)
        except Exception as e:
            messagebox.showerror("❌ Error", f"Prediction failed:\n{e}")
            self.hide_loading()
            return
        
        # Hide loading and show results
        self.hide_loading()
        self.show_results(probs, final_prob, label)
    
    def show_loading(self):
        """Show loading animation"""
        loading_frame = tk.Frame(self.root, bg='#ffffff', bd=1, relief='solid')
        loading_frame.place(relx=0.5, rely=0.75, anchor='center', width=300, height=100)
        
        loading_label = tk.Label(loading_frame, 
                                text="🔄 Analyzing signature...", 
                                font=("Inter", 12, "bold"), 
                                fg='#667eea', 
                                bg='#ffffff')
        loading_label.pack(expand=True)
        
        self.loading_frame = loading_frame
        self.root.update()
    
    def hide_loading(self):
        """Hide loading animation"""
        if hasattr(self, 'loading_frame'):
            self.loading_frame.destroy()
    
    def show_results(self, probs, final_prob, label):
        """Display results with modern styling"""
        # Position results frame
        self.results_frame.place(relx=0.5, rely=0.75, anchor='center', width=500, height=200)
        
        # Format individual model scores
        lines = []
        for k in ["cnn_a", "cnn_b", "svm", "rf"]:
            if k in probs:
                lines.append(f"{k.upper():6s}: {probs[k]*100:6.2f}%")
        lines.append("─" * 25)
        lines.append(f"FINAL : {final_prob*100:6.2f}%")
        
        self.detail.config(text="\n".join(lines))
        
        # Set result with appropriate styling
        if label == 1:
            self.result.config(
                text=f"✅ LEGITIMATE SIGNATURE\nConfidence: {final_prob*100:.2f}%", 
                fg="#27ae60"
            )
        else:
            self.result.config(
                text=f"⚠️ FORGERY DETECTED\nConfidence: {(1-final_prob)*100:.2f}%", 
                fg="#e74c3c"
            )
            
            # Send email if forgery detected and email provided
            email_addr = self.email.get().strip()
            if HAS_MAILING and email_addr and email_addr != "Enter your email address":
                try:
                    mailing.mailsend(
                        email_addr,
                        "🚨 Signature Forgery Detected",
                        f"Forgery detected with {(1-final_prob)*100:.2f}% confidence on {os.path.basename(self.filepath)}"
                    )
                    messagebox.showinfo("📧 Email Sent", "Fraud alert email has been sent successfully!")
                except Exception as e:
                    messagebox.showwarning("⚠️ Email Error", f"Could not send email: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("1200x800")
    root.resizable(True, True)
    root.minsize(800, 600)
    
    # Set window icon if available
    try:
        root.iconbitmap('icon.ico')
    except:
        pass
    
    # Center window on screen
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (1200 // 2)
    y = (root.winfo_screenheight() // 2) - (800 // 2)
    root.geometry(f"1200x800+{x}+{y}")
    
    App(root)
    root.mainloop()
