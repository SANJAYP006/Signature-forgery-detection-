# debug_predictions.py - Quick test to see raw model outputs
import numpy as np
from keras.models import load_model
from keras.preprocessing import image
import joblib
from ensemble_predictor import EnsemblePredictor

def test_single_image(img_path):
    """Test a single image with all models to see raw outputs"""
    print(f"Testing image: {img_path}")
    print("="*50)
    
    # Test CNN A
    try:
        model_a = load_model("models/cnn_a.h5")
        test_image = image.load_img(img_path, target_size=(224, 224))
        test_image = image.img_to_array(test_image)
        test_image = np.expand_dims(test_image, axis=0)
        test_image = test_image / 255.0
        result_a = model_a.predict(test_image, verbose=0)
        print(f"CNN A raw output: {result_a[0]}")
        print(f"CNN A shape: {result_a.shape}")
    except Exception as e:
        print(f"CNN A error: {e}")
    
    # Test CNN B
    try:
        model_b = load_model("models/cnn_b.h5")
        result_b = model_b.predict(test_image, verbose=0)
        print(f"CNN B raw output: {result_b[0]}")
        print(f"CNN B shape: {result_b.shape}")
    except Exception as e:
        print(f"CNN B error: {e}")
    
    print("="*50)
    
    # Test with ensemble
    try:
        ensemble = EnsemblePredictor()
        prediction_type, confidence, individual_scores, is_high_confidence = ensemble.ensemble_predict(img_path)
        print(f"Ensemble result: {prediction_type}")
        print(f"Confidence: {confidence}%")
        print(f"Individual scores: {individual_scores}")
    except Exception as e:
        print(f"Ensemble error: {e}")

if __name__ == "__main__":
    # Test with a sample image from your uploads
    import os
    upload_dir = "static/uploads"
    if os.path.exists(upload_dir):
        files = [f for f in os.listdir(upload_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        if files:
            test_img = os.path.join(upload_dir, files[0])
            test_single_image(test_img)
        else:
            print("No images found in uploads directory")
    else:
        print("Uploads directory not found")
