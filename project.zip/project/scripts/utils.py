# scripts/utils.py
import os
import numpy as np
import cv2
from PIL import Image, ImageOps
from skimage.feature import hog, local_binary_pattern

# --- Preprocessing for CNN and handcrafted features ---
def preprocess_for_cnn(pil_img, target_size=(224, 224)):
    """
    Steps: grayscale -> blur -> Otsu binarize -> invert if needed -> bbox crop -> pad square -> resize -> normalize
    Returns:
      cnn_img: float32 HxWx1 in [0,1]
      bin_for_feats: uint8 (0/1) for handcrafted feature extraction
    """
    gray = ImageOps.grayscale(pil_img)
    arr = np.array(gray)

    # Blur + Otsu threshold
    arr_blur = cv2.GaussianBlur(arr, (5, 5), 0)
    _, bin_img = cv2.threshold(arr_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Invert if needed (ensure background = black, ink = white)
    if bin_img.mean() < 127:
        bin_inv = cv2.bitwise_not(bin_img)
    else:
        bin_inv = bin_img

    # Crop bounding box
    coords = cv2.findNonZero(255 - bin_inv)
    if coords is not None:
        x, y, w, h = cv2.boundingRect(coords)
        cropped = (255 - bin_inv)[y:y + h, x:x + w]
    else:
        cropped = 255 - bin_inv

    # Pad to square
    h, w = cropped.shape[:2]
    side = max(h, w)
    pad_top = (side - h) // 2
    pad_bottom = side - h - pad_top
    pad_left = (side - w) // 2
    pad_right = side - w - pad_left
    squared = cv2.copyMakeBorder(
        cropped, pad_top, pad_bottom, pad_left, pad_right,
        borderType=cv2.BORDER_CONSTANT, value=0
    )

    # Resize
    resized = cv2.resize(squared, target_size, interpolation=cv2.INTER_AREA)

    # CNN input (HxWx1) in [0,1]
    cnn_img = resized.astype("float32") / 255.0
    cnn_img = np.expand_dims(cnn_img, axis=-1)

    # Binary for handcrafted features (0/1)
    bin_for_feats = (resized < 128).astype("uint8")

    return cnn_img, bin_for_feats


# --- Handcrafted features (HOG + LBP) ---
def extract_handcrafted(bin_img):
    """
    Extracts handcrafted features from a binary signature image.
    Uses Histogram of Oriented Gradients (HOG) + Local Binary Patterns (LBP).
    """
    # HOG
    hog_feats = hog(bin_img, pixels_per_cell=(16, 16), cells_per_block=(2, 2), feature_vector=True)

    # LBP (uniform, 8 neighbors, radius 1)
    lbp = local_binary_pattern(bin_img, P=8, R=1, method="uniform")
    (hist, _) = np.histogram(lbp.ravel(), bins=np.arange(0, 10), range=(0, 9))
    hist = hist.astype("float")
    hist /= (hist.sum() + 1e-7)

    return np.hstack([hog_feats, hist])


# --- Walk through dataset folders ---
def walk_images(base_dir, classes):
    """
    Yields (image_path, class_index) for all images under base_dir.
    Expects subfolders named according to 'classes'
    e.g., classes=['forgery','genuine'] => base_dir/forgery, base_dir/genuine
    """
    for label_idx, cls in enumerate(classes):
        cls_dir = os.path.join(base_dir, cls)
        if not os.path.isdir(cls_dir):
            continue
        for fname in os.listdir(cls_dir):
            if fname.lower().endswith((".png", ".jpg", ".jpeg")):
                path = os.path.join(cls_dir, fname)
                yield path, label_idx
