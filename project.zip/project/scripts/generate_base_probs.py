# scripts/generate_base_probs.py
import os
import numpy as np
import joblib
from PIL import Image

try:
    from scripts.utils import preprocess_for_cnn, extract_handcrafted, walk_images
except ImportError:
    from utils import preprocess_for_cnn, extract_handcrafted, walk_images

BASE_DIR    = os.path.dirname(os.path.dirname(__file__))
DATA_DIR    = os.path.join(BASE_DIR, "dataset")
VAL_DIR     = os.path.join(DATA_DIR, "val")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUTS_DIR, exist_ok=True)

CLASSES = ["forgery", "genuine"]  # class 1 = genuine

svm    = joblib.load(os.path.join(MODELS_DIR, "svm_hog_lbp.joblib"))
rf     = joblib.load(os.path.join(MODELS_DIR, "rf_hog_lbp.joblib"))
scaler = joblib.load(os.path.join(MODELS_DIR, "scaler.joblib"))

try:
    from tensorflow.keras.models import load_model
    cnn_a = load_model(os.path.join(MODELS_DIR, "cnn_a.h5"))
    cnn_b = load_model(os.path.join(MODELS_DIR, "cnn_b.h5"))
    use_cnn = True
    print("✅ CNN models loaded")
except Exception:
    print("[WARN] CNN models not found, using dummy 0.5 probs.")
    cnn_a = cnn_b = None
    use_cnn = False

X_probs, y_true = [], []

for path, label in walk_images(VAL_DIR, CLASSES):
    pil = Image.open(path).convert("RGB")
    arr, bin_img = preprocess_for_cnn(pil, target_size=(224, 224))

    # CNN probabilities (prob of class index 1 = genuine)
    if use_cnn:
        if arr.shape[-1] == 1:
            arr = np.repeat(arr, 3, axis=-1)
        p_cnn_a = float(cnn_a.predict(arr[np.newaxis, ...], verbose=0)[0][1])
        p_cnn_b = float(cnn_b.predict(arr[np.newaxis, ...], verbose=0)[0][1])
    else:
        p_cnn_a = p_cnn_b = 0.5

    feats = extract_handcrafted(bin_img).reshape(1, -1)
    feats_scaled = scaler.transform(feats)
    p_svm = float(svm.predict_proba(feats_scaled)[0][1])
    p_rf  = float(rf.predict_proba(feats_scaled)[0][1])

    X_probs.append([p_cnn_a, p_cnn_b, p_svm, p_rf])
    y_true.append(label)

blob = {"X": np.array(X_probs, dtype=np.float32), "y": np.array(y_true, dtype=np.int64)}
out_path = os.path.join(OUTPUTS_DIR, "base_probs.npy")
np.save(out_path, blob)

print(f"✅ Saved base_probs.npy -> {out_path}")
print("X shape:", blob["X"].shape, "| y shape:", blob["y"].shape)
