# scripts/classical_train.py
import os
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from PIL import Image

try:
    from scripts.utils import preprocess_for_cnn, extract_handcrafted, walk_images
except ImportError:
    from utils import preprocess_for_cnn, extract_handcrafted, walk_images

BASE_DIR   = os.path.dirname(os.path.dirname(__file__))
DATA_DIR   = os.path.join(BASE_DIR, 'dataset')
TRAIN_DIR  = os.path.join(DATA_DIR, 'train')
VAL_DIR    = os.path.join(DATA_DIR, 'val')
MODELS_DIR = os.path.join(BASE_DIR, 'models')
os.makedirs(MODELS_DIR, exist_ok=True)

CLASSES = ['forgery', 'genuine']

def load_features(data_dir):
    X_list, y_list = [], []
    for path, label in walk_images(data_dir, CLASSES):
        pil = Image.open(path).convert('RGB')
        _, bin_img = preprocess_for_cnn(pil, target_size=(224, 224))
        feats = extract_handcrafted(bin_img)  # fixed-length vector
        X_list.append(feats)
        y_list.append(label)

    if not X_list:
        raise RuntimeError(f"No images found in {data_dir}")

    X = np.vstack(X_list).astype(np.float32)  # shape (N, F)
    y = np.array(y_list, dtype=np.int64)
    print(f"[DEBUG] Loaded {X.shape[0]} samples from {data_dir}, X shape={X.shape}, y shape={y.shape}")
    return X, y

# Load
X_train, y_train = load_features(TRAIN_DIR)
X_val,   y_val   = load_features(VAL_DIR)

# Scale
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled   = scaler.transform(X_val)

# Train
svm = SVC(kernel='linear', probability=True, random_state=42)
svm.fit(X_train_scaled, y_train)

rf = RandomForestClassifier(n_estimators=300, random_state=42)
rf.fit(X_train_scaled, y_train)

# Evaluate
svm_acc = accuracy_score(y_val, svm.predict(X_val_scaled))
rf_acc  = accuracy_score(y_val,  rf.predict(X_val_scaled))
print(f"SVM Accuracy: {svm_acc:.4f}")
print(f"RF  Accuracy: {rf_acc:.4f}")

# Save
joblib.dump(svm,    os.path.join(MODELS_DIR, "svm_hog_lbp.joblib"))
joblib.dump(rf,     os.path.join(MODELS_DIR, "rf_hog_lbp.joblib"))
joblib.dump(scaler, os.path.join(MODELS_DIR, "scaler.joblib"))
print('✅ Models saved in:', MODELS_DIR)
