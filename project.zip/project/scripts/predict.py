# scripts/predict.py
import os
import joblib
import numpy as np
import pandas as pd
from PIL import Image

try:
    from scripts.utils import preprocess_for_cnn, extract_handcrafted
    from scripts.emailer import send_forgery_email
except ImportError:
    from utils import preprocess_for_cnn, extract_handcrafted
    from emailer import send_forgery_email

# --- Default Paths & Email ---
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

# Your dataset test folder
TEST_FOLDER = r"C:\Users\sanja\Desktop\dap 2\project\dataset\test"
# Your email for alerts
DEFAULT_EMAIL = "sanjaymparamesh006@gmail.com"

STACKER_PATH = os.path.join(MODELS_DIR, "stacker.joblib")
SVM_PATH     = os.path.join(MODELS_DIR, "svm_hog_lbp.joblib")
RF_PATH      = os.path.join(MODELS_DIR, "rf_hog_lbp.joblib")
SCALER_PATH  = os.path.join(MODELS_DIR, "scaler.joblib")

# Load models
svm     = joblib.load(SVM_PATH)
rf      = joblib.load(RF_PATH)
scaler  = joblib.load(SCALER_PATH)
stacker = joblib.load(STACKER_PATH)

try:
    from tensorflow.keras.models import load_model
    cnn_a = load_model(os.path.join(MODELS_DIR, "cnn_a.h5"))
    cnn_b = load_model(os.path.join(MODELS_DIR, "cnn_b.h5"))
    use_cnn = True
except Exception:
    cnn_a = cnn_b = None
    use_cnn = False
    print("[WARN] CNN models not found, using only handcrafted features.")


def predict_scores(path):
    """Returns (final_prob_genuine, features_vector[cnn_a, cnn_b, svm, rf])."""
    pil = Image.open(path).convert("RGB")
    arr, bin_img = preprocess_for_cnn(pil, target_size=(224, 224))

    # CNN predictions
    if use_cnn:
        if arr.shape[-1] == 1:  # expand grayscale to RGB if needed
            arr = np.repeat(arr, 3, axis=-1)
        p_cnn_a = float(cnn_a.predict(arr[np.newaxis, ...], verbose=0)[0][1])
        p_cnn_b = float(cnn_b.predict(arr[np.newaxis, ...], verbose=0)[0][1])
    else:
        p_cnn_a = p_cnn_b = 0.5

    # Handcrafted features
    feats = extract_handcrafted(bin_img).reshape(1, -1)
    feats_scaled = scaler.transform(feats)
    p_svm = float(svm.predict_proba(feats_scaled)[0][1])
    p_rf  = float(rf.predict_proba(feats_scaled)[0][1])

    probs = np.array([[p_cnn_a, p_cnn_b, p_svm, p_rf]])
    final_prob_genuine = float(stacker.predict_proba(probs)[0][1])  # prob of class 'genuine'
    return final_prob_genuine, probs[0].tolist()


def predict_image(path, alert_email: str | None = None, forgery_threshold: float = 0.7):
    """
    Predict for a single image and send alert email if genuine probability < threshold (default 70%).
    """
    final_prob_genuine, base_probs = predict_scores(path)
    final_prob_forgery = 1.0 - final_prob_genuine

    # classify
    predicted_class = "genuine" if final_prob_genuine >= forgery_threshold else "forgery"

    # Email if forgery condition met
    if alert_email and final_prob_genuine < forgery_threshold:
        try:
            send_forgery_email(
                to_email=alert_email,
                image_name=os.path.basename(path),
                prob=final_prob_forgery
            )
            email_status = "sent"
        except Exception as e:
            email_status = f"failed: {e}"
    else:
        email_status = "skipped"

    return {
        "image": os.path.basename(path),
        "prediction": predicted_class,
        "probabilities": {
            "genuine": final_prob_genuine,
            "forgery": final_prob_forgery
        },
        "base_probs": {
            "cnn_a_genuine": base_probs[0],
            "cnn_b_genuine": base_probs[1],
            "svm_genuine":   base_probs[2],
            "rf_genuine":    base_probs[3],
        },
        "email": email_status
    }


def predict_folder(folder_path, out_csv="predictions.csv", alert_email: str | None = None, forgery_threshold: float = 0.7):
    """
    Predict all images in a folder and save to CSV. 
    Emails on each forgery if alert_email provided and prob_genuine < threshold.
    """
    results = []
    for fname in os.listdir(folder_path):
        fpath = os.path.join(folder_path, fname)
        if not os.path.isfile(fpath):
            continue
        try:
            out = predict_image(fpath, alert_email=alert_email, forgery_threshold=forgery_threshold)
            results.append({
                "image": fname,
                "prediction": out["prediction"],
                "prob_genuine": out["probabilities"]["genuine"],
                "prob_forgery": out["probabilities"]["forgery"],
                "email": out["email"]
            })
            print(f"[OK] {fname} -> {out['prediction']} (genuine={out['probabilities']['genuine']:.4f}, email={out['email']})")
        except Exception as e:
            print(f"[ERR] {fname}: {e}")

    df = pd.DataFrame(results)
    out_path = os.path.join(folder_path, out_csv)
    df.to_csv(out_path, index=False)
    print(f"✅ Saved predictions to {out_path}")


if __name__ == "__main__":
    # Run directly without arguments
    predict_folder(TEST_FOLDER, alert_email=DEFAULT_EMAIL, forgery_threshold=0.7)
