# scripts/stacker_train.py
import os
import numpy as np
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

# --- Paths ---
BASE_DIR    = os.path.dirname(os.path.dirname(__file__))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

PROBS_PATH  = os.path.join(OUTPUTS_DIR, "base_probs.npy")
STACKER_PATH = os.path.join(MODELS_DIR, "stacker.joblib")

print("🔍 Loading base probabilities...")
if not os.path.exists(PROBS_PATH):
    raise FileNotFoundError(f"[ERROR] base_probs.npy not found at {PROBS_PATH}. "
                            f"Run scripts/generate_base_probs.py first!")

# --- Load base probabilities ---
blob = np.load(PROBS_PATH, allow_pickle=True).item()
X, y = blob["X"], blob["y"]

print(f"✅ base_probs.npy loaded successfully!")
print(f"   X shape: {X.shape} | y shape: {y.shape}")

# --- Train/test split ---
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"📊 Train set: {X_train.shape}, Validation set: {X_val.shape}")

# --- Train logistic regression stacker ---
print("⚙️ Training Logistic Regression stacker...")
stacker = LogisticRegression(max_iter=500)
stacker.fit(X_train, y_train)

# --- Evaluate ---
y_pred = stacker.predict(X_val)
acc = accuracy_score(y_val, y_pred)
print(f"🎯 Validation Accuracy: {acc * 100:.2f}%")

# --- Save model ---
joblib.dump(stacker, STACKER_PATH)
print(f"💾 Saved stacker model -> {STACKER_PATH}")
