import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.patches import Rectangle
import pandas as pd

# Set style for better visualization
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

# Model performance data
models = ['CNN Model A', 'CNN Model B', 'Random Forest', 'SVM', 'Ensemble']
accuracy = [87.3, 89.6, 82.4, 79.8, 92.7]
precision = [85.7, 88.9, 81.2, 78.5, 91.8]
recall = [89.2, 90.1, 83.8, 81.3, 93.4]
f1_score = [87.4, 89.5, 82.5, 79.9, 92.6]
processing_time = [1200, 2800, 450, 320, 4770]
memory_usage = [145, 287, 67, 42, 541]

# Create comprehensive visualization
fig = plt.figure(figsize=(20, 12))

# 1. Performance Metrics Comparison (Radar Chart)
ax1 = plt.subplot(2, 3, 1, projection='polar')
angles = np.linspace(0, 2 * np.pi, 4, endpoint=False).tolist()
angles += angles[:1]  # Complete the circle

# Plot each model
colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
for i, model in enumerate(models):
    values = [accuracy[i], precision[i], recall[i], f1_score[i]]
    values += values[:1]  # Complete the circle
    
    ax1.plot(angles, values, 'o-', linewidth=2, label=model, color=colors[i])
    ax1.fill(angles, values, alpha=0.25, color=colors[i])

ax1.set_xticks(angles[:-1])
ax1.set_xticklabels(['Accuracy', 'Precision', 'Recall', 'F1-Score'])
ax1.set_ylim(0, 100)
ax1.set_title('Performance Metrics Comparison\n(Radar Chart)', size=14, fontweight='bold', pad=20)
ax1.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))

# 2. Accuracy Comparison Bar Chart
ax2 = plt.subplot(2, 3, 2)
bars = ax2.bar(models, accuracy, color=colors, alpha=0.8, edgecolor='black', linewidth=1)
ax2.set_ylabel('Accuracy (%)', fontweight='bold')
ax2.set_title('Model Accuracy Comparison', fontweight='bold', fontsize=14)
ax2.set_ylim(70, 100)

# Add value labels on bars
for bar, acc in zip(bars, accuracy):
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height + 0.5,
             f'{acc}%', ha='center', va='bottom', fontweight='bold')

plt.setp(ax2.get_xticklabels(), rotation=45, ha='right')

# 3. Processing Time vs Memory Usage Scatter Plot
ax3 = plt.subplot(2, 3, 3)
scatter = ax3.scatter(processing_time, memory_usage, c=accuracy, s=200, 
                     cmap='RdYlGn', alpha=0.8, edgecolors='black', linewidth=2)

# Add model labels
for i, model in enumerate(models):
    ax3.annotate(model, (processing_time[i], memory_usage[i]), 
                xytext=(5, 5), textcoords='offset points', fontsize=10, fontweight='bold')

ax3.set_xlabel('Processing Time (ms)', fontweight='bold')
ax3.set_ylabel('Memory Usage (MB)', fontweight='bold')
ax3.set_title('Efficiency Analysis\n(Processing Time vs Memory)', fontweight='bold', fontsize=14)

# Add colorbar
cbar = plt.colorbar(scatter, ax=ax3)
cbar.set_label('Accuracy (%)', fontweight='bold')

# 4. Performance Metrics Heatmap
ax4 = plt.subplot(2, 3, 4)
metrics_data = np.array([accuracy, precision, recall, f1_score]).T
df_metrics = pd.DataFrame(metrics_data, 
                         index=models, 
                         columns=['Accuracy', 'Precision', 'Recall', 'F1-Score'])

sns.heatmap(df_metrics, annot=True, fmt='.1f', cmap='RdYlGn', 
           cbar_kws={'label': 'Performance (%)'}, ax=ax4)
ax4.set_title('Performance Metrics Heatmap', fontweight='bold', fontsize=14)
ax4.set_ylabel('Models', fontweight='bold')

# 5. Ensemble Weight Distribution Pie Chart
ax5 = plt.subplot(2, 3, 5)
ensemble_weights = [35, 35, 15, 15]
ensemble_models = ['CNN Model A', 'CNN Model B', 'Random Forest', 'SVM']
colors_pie = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']

wedges, texts, autotexts = ax5.pie(ensemble_weights, labels=ensemble_models, 
                                  autopct='%1.1f%%', colors=colors_pie, 
                                  explode=(0.05, 0.05, 0.05, 0.05),
                                  shadow=True, startangle=90)

ax5.set_title('Ensemble Weight Distribution', fontweight='bold', fontsize=14)

# Make percentage text bold
for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')
    autotext.set_fontsize(10)

# 6. Cross-Validation Performance
ax6 = plt.subplot(2, 3, 6)
cv_folds = ['Fold 1', 'Fold 2', 'Fold 3', 'Fold 4', 'Fold 5']
ensemble_cv = [91.2, 93.1, 92.8, 91.9, 94.5]
cnn_a_cv = [86.1, 88.2, 87.9, 86.8, 88.5]
cnn_b_cv = [88.3, 90.1, 89.7, 89.2, 91.0]

ax6.plot(cv_folds, ensemble_cv, 'o-', linewidth=3, markersize=8, 
         label='Ensemble', color='#9b59b6')
ax6.plot(cv_folds, cnn_a_cv, 's--', linewidth=2, markersize=6, 
         label='CNN Model A', color='#3498db')
ax6.plot(cv_folds, cnn_b_cv, '^--', linewidth=2, markersize=6, 
         label='CNN Model B', color='#e74c3c')

ax6.set_ylabel('Accuracy (%)', fontweight='bold')
ax6.set_xlabel('Cross-Validation Folds', fontweight='bold')
ax6.set_title('Cross-Validation Performance', fontweight='bold', fontsize=14)
ax6.legend()
ax6.grid(True, alpha=0.3)
ax6.set_ylim(80, 100)

# Adjust layout and add main title
plt.tight_layout()
fig.suptitle('Signature Fraud Detection System - Model Performance Analysis', 
             fontsize=20, fontweight='bold', y=0.98)

# Add subtitle with system information
fig.text(0.5, 0.02, 'Comprehensive Evaluation Report | Generated: September 2025 | System Version: 2.1.0', 
         ha='center', fontsize=12, style='italic', color='gray')

# Save the plot
plt.savefig('c:/Users/sanja/Desktop/dap 2/project/model_performance_analysis.png', 
           dpi=300, bbox_inches='tight', facecolor='white')

# Display the plot
plt.show()

print("Model Performance Visualization Generated Successfully!")
print("Saved as: model_performance_analysis.png")
print("\nVisualization Components:")
print("1. Radar Chart - Overall performance metrics comparison")
print("2. Bar Chart - Accuracy comparison across models")
print("3. Scatter Plot - Efficiency analysis (processing time vs memory)")
print("4. Heatmap - Performance metrics matrix")
print("5. Pie Chart - Ensemble weight distribution")
print("6. Line Plot - Cross-validation performance trends")
