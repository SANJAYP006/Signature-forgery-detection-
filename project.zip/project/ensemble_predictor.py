# ensemble_predictor.py
import numpy as np
import joblib
from keras.models import load_model
from keras.preprocessing import image
from skimage.feature import hog, local_binary_pattern
from skimage import exposure
import cv2
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EnsemblePredictor:
    def __init__(self):
        self.models = {}
        self.scaler = None
        self.load_models()
    
    def load_models(self):
        """Load all available models"""
        try:
            # Load CNN models
            self.models['cnn_a'] = load_model("models/cnn_a.h5")
            self.models['cnn_b'] = load_model("models/cnn_b.h5")
            logger.info("✅ CNN models loaded successfully")
            
            # Load classical ML models
            self.models['rf'] = joblib.load("models/rf_hog_lbp.joblib")
            self.models['svm'] = joblib.load("models/svm_hog_lbp.joblib")
            self.scaler = joblib.load("models/scaler.joblib")
            logger.info("✅ Classical ML models loaded successfully")
            
            # Load stacker if available
            try:
                self.models['stacker'] = joblib.load("models/stacker.joblib")
                logger.info("✅ Stacker model loaded successfully")
            except:
                logger.info("ℹ️ Stacker model not found, using weighted ensemble")
                
        except Exception as e:
            logger.error(f"❌ Error loading models: {e}")
            raise
    
    def extract_hog_lbp_features(self, img_path):
        """Extract HOG and LBP features for classical ML models using training parameters"""
        try:
            # Load image and preprocess using the same method as training
            from PIL import Image
            pil_img = Image.open(img_path).convert('RGB')
            
            # Use the same preprocessing as training
            from scripts.utils import preprocess_for_cnn, extract_handcrafted
            _, bin_img = preprocess_for_cnn(pil_img, target_size=(224, 224))
            
            # Extract features using the same method as training
            features = extract_handcrafted(bin_img)
            logger.info(f"Extracted {len(features)} features")
            return features.reshape(1, -1)
            
        except Exception as e:
            logger.error(f"❌ Error extracting features: {e}")
            raise
    
    def predict_cnn(self, img_path, model_name):
        """Predict using CNN models"""
        try:
            # Preprocess image for CNN
            test_image = image.load_img(img_path, target_size=(224, 224))
            test_image = image.img_to_array(test_image)
            test_image = np.expand_dims(test_image, axis=0)
            test_image = test_image / 255.0
            
            # Get prediction
            result = self.models[model_name].predict(test_image, verbose=0)
            
            # Handle different output formats - FIXED LOGIC
            if result.shape[1] == 1:
                # Binary classification - single output
                prob = float(result[0][0])
                # If prob > 0.5, it's class 1 (legitimate), else class 0 (forgery)
                fraud_prob = 1 - prob  # Convert to fraud probability
            else:
                # Multi-class - [forgery_prob, legitimate_prob]
                fraud_prob = float(result[0][0])  # Class 0 is forgery
                
            logger.info(f"{model_name} raw output: {result[0]}, fraud_prob: {fraud_prob}")
            return fraud_prob
            
        except Exception as e:
            logger.error(f"❌ Error in CNN prediction ({model_name}): {e}")
            return 0.5  # Default to neutral
    
    def predict_classical(self, img_path, model_name):
        """Predict using classical ML models"""
        try:
            # Extract features
            features = self.extract_hog_lbp_features(img_path)
            
            # Scale features
            if self.scaler:
                features = self.scaler.transform(features)
            
            # Get prediction probabilities
            if hasattr(self.models[model_name], 'predict_proba'):
                proba = self.models[model_name].predict_proba(features)[0]
                # Check if class 0 is forgery or legitimate based on training
                # Most likely: class 0 = forgery, class 1 = legitimate
                fraud_prob = proba[0] if len(proba) > 1 else (1 - proba[0])
            else:
                # For models without predict_proba, use decision function
                decision = self.models[model_name].decision_function(features)[0]
                fraud_prob = 1 / (1 + np.exp(-decision))  # Sigmoid
            
            logger.info(f"{model_name} probabilities: {proba if 'proba' in locals() else 'N/A'}, fraud_prob: {fraud_prob}")
            return float(fraud_prob)
            
        except Exception as e:
            logger.error(f"❌ Error in classical prediction ({model_name}): {e}")
            return 0.5  # Default to neutral
    
    def ensemble_predict(self, img_path, confidence_threshold=0.75):
        """
        Ensemble prediction using weighted voting
        Returns: (prediction_type, confidence, individual_scores, is_high_confidence)
        """
        try:
            predictions = {}
            
            # CNN predictions (higher weight due to better performance on images)
            predictions['cnn_a'] = self.predict_cnn(img_path, 'cnn_a')
            predictions['cnn_b'] = self.predict_cnn(img_path, 'cnn_b')
            
            # Classical ML predictions
            predictions['rf'] = self.predict_classical(img_path, 'rf')
            predictions['svm'] = self.predict_classical(img_path, 'svm')
            
            # Weighted ensemble (CNNs get higher weights)
            weights = {
                'cnn_a': 0.35,
                'cnn_b': 0.35,
                'rf': 0.15,
                'svm': 0.15
            }
            
            # Calculate weighted average
            weighted_fraud_prob = sum(predictions[model] * weights[model] 
                                    for model in predictions.keys())
            
            # Calculate confidence (always as percentage of certainty)
            if weighted_fraud_prob > 0.5:
                confidence = round(weighted_fraud_prob * 100, 2)
            else:
                confidence = round((1 - weighted_fraud_prob) * 100, 2)
            
            # Only show FORGERY if confidence is less than 70%
            if confidence < 70:
                prediction_type = "DETECTED TYPE IS : FORGERY"
            else:
                prediction_type = "DETECTED TYPE IS : LEGITIMATE"
            
            # Check if confidence is high enough
            is_high_confidence = confidence >= (confidence_threshold * 100)
            
            logger.info(f"Ensemble prediction: {prediction_type} ({confidence}%)")
            logger.info(f"Individual scores: {predictions}")
            
            return prediction_type, confidence, predictions, is_high_confidence
            
        except Exception as e:
            logger.error(f"❌ Error in ensemble prediction: {e}")
            # Fallback to single model
            try:
                fraud_prob = self.predict_cnn(img_path, 'cnn_a')
                if fraud_prob > 0.5:
                    return "DETECTED TYPE IS : FORGERY", round(fraud_prob * 100, 2), {}, False
                else:
                    return "DETECTED TYPE IS : LEGITIMATE", round((1-fraud_prob) * 100, 2), {}, False
            except:
                return "ERROR IN PREDICTION", 0.0, {}, False
