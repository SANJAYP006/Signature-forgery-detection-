#!/usr/bin/env python3
"""
Batch Evaluation Script for Signature Fraud Detection System
Evaluates the ensemble predictor on test dataset and generates accuracy report.
"""

import os
import glob
import pandas as pd
import numpy as np
from datetime import datetime
import logging
from ensemble_predictor import EnsemblePredictor
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class BatchEvaluator:
    def __init__(self, test_data_path="dataset/test"):
        self.test_data_path = test_data_path
        self.forgery_path = os.path.join(test_data_path, "forgery")
        self.genuine_path = os.path.join(test_data_path, "genuine")
        self.predictor = EnsemblePredictor()
        self.results = []
        
    def get_image_files(self, folder_path):
        """Get all image files from a folder"""
        image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']
        image_files = []
        
        for ext in image_extensions:
            pattern = os.path.join(folder_path, ext)
            image_files.extend(glob.glob(pattern, recursive=False))
            # Also check for uppercase extensions
            pattern_upper = os.path.join(folder_path, ext.upper())
            image_files.extend(glob.glob(pattern_upper, recursive=False))
        
        return image_files
    
    def evaluate_folder(self, folder_path, true_label, label_name):
        """Evaluate all images in a folder"""
        logger.info(f"🔍 Evaluating {label_name} images from: {folder_path}")
        
        image_files = self.get_image_files(folder_path)
        logger.info(f"Found {len(image_files)} image files")
        
        folder_results = []
        successful_predictions = 0
        
        for i, img_path in enumerate(image_files, 1):
            try:
                logger.info(f"Processing {i}/{len(image_files)}: {os.path.basename(img_path)}")
                
                # Get prediction from ensemble
                prediction_type, confidence, individual_scores, is_high_confidence = \
                    self.predictor.ensemble_predict(img_path)
                
                # Convert prediction to binary (1 for forgery, 0 for genuine)
                predicted_label = 1 if "FORGERY" in prediction_type else 0
                
                # Calculate fraud probability for consistency
                if predicted_label == 1:
                    fraud_probability = confidence / 100.0
                else:
                    fraud_probability = (100 - confidence) / 100.0
                
                result = {
                    'image_path': img_path,
                    'image_name': os.path.basename(img_path),
                    'true_label': true_label,
                    'true_label_name': label_name,
                    'predicted_label': predicted_label,
                    'prediction_type': prediction_type,
                    'confidence': confidence,
                    'fraud_probability': fraud_probability,
                    'is_high_confidence': is_high_confidence,
                    'individual_scores': individual_scores,
                    'correct': predicted_label == true_label
                }
                
                folder_results.append(result)
                self.results.append(result)
                successful_predictions += 1
                
            except Exception as e:
                logger.error(f"❌ Error processing {img_path}: {e}")
                # Add failed prediction to results
                result = {
                    'image_path': img_path,
                    'image_name': os.path.basename(img_path),
                    'true_label': true_label,
                    'true_label_name': label_name,
                    'predicted_label': -1,  # Error indicator
                    'prediction_type': "ERROR",
                    'confidence': 0,
                    'fraud_probability': 0,
                    'is_high_confidence': False,
                    'individual_scores': {},
                    'correct': False,
                    'error': str(e)
                }
                folder_results.append(result)
                self.results.append(result)
        
        logger.info(f"✅ Completed {label_name}: {successful_predictions}/{len(image_files)} successful predictions")
        return folder_results
    
    def calculate_metrics(self, results):
        """Calculate accuracy metrics from results"""
        # Filter out error predictions
        valid_results = [r for r in results if r['predicted_label'] != -1]
        
        if not valid_results:
            return {}
        
        y_true = [r['true_label'] for r in valid_results]
        y_pred = [r['predicted_label'] for r in valid_results]
        
        metrics = {
            'total_samples': len(results),
            'valid_predictions': len(valid_results),
            'failed_predictions': len(results) - len(valid_results),
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1_score': f1_score(y_true, y_pred, average='weighted', zero_division=0),
            'confusion_matrix': confusion_matrix(y_true, y_pred).tolist()
        }
        
        # Calculate per-class metrics
        if len(set(y_true)) > 1:  # Only if we have both classes
            metrics['precision_per_class'] = precision_score(y_true, y_pred, average=None, zero_division=0).tolist()
            metrics['recall_per_class'] = recall_score(y_true, y_pred, average=None, zero_division=0).tolist()
            metrics['f1_per_class'] = f1_score(y_true, y_pred, average=None, zero_division=0).tolist()
        
        return metrics
    
    def run_evaluation(self):
        """Run complete batch evaluation"""
        logger.info("🚀 Starting batch evaluation of signature fraud detection system")
        logger.info(f"Test data path: {self.test_data_path}")
        
        # Evaluate forgery images (label = 1)
        logger.info("\n" + "="*50)
        logger.info("EVALUATING FORGERY IMAGES")
        logger.info("="*50)
        forgery_results = self.evaluate_folder(self.forgery_path, 1, "Forgery")
        
        # Evaluate genuine images (label = 0)
        logger.info("\n" + "="*50)
        logger.info("EVALUATING GENUINE IMAGES")
        logger.info("="*50)
        genuine_results = self.evaluate_folder(self.genuine_path, 0, "Genuine")
        
        # Calculate overall metrics
        logger.info("\n" + "="*50)
        logger.info("CALCULATING METRICS")
        logger.info("="*50)
        
        overall_metrics = self.calculate_metrics(self.results)
        forgery_metrics = self.calculate_metrics(forgery_results)
        genuine_metrics = self.calculate_metrics(genuine_results)
        
        # Generate report
        report = self.generate_report(overall_metrics, forgery_metrics, genuine_metrics)
        
        # Save results
        self.save_results(report)
        
        logger.info("✅ Batch evaluation completed successfully!")
        return report
    
    def generate_report(self, overall_metrics, forgery_metrics, genuine_metrics):
        """Generate comprehensive evaluation report"""
        report = {
            'evaluation_timestamp': datetime.now().isoformat(),
            'dataset_info': {
                'test_data_path': self.test_data_path,
                'forgery_images': len([r for r in self.results if r['true_label'] == 1]),
                'genuine_images': len([r for r in self.results if r['true_label'] == 0]),
                'total_images': len(self.results)
            },
            'overall_performance': overall_metrics,
            'forgery_performance': forgery_metrics,
            'genuine_performance': genuine_metrics,
            'detailed_results': self.results
        }
        
        # Print summary to console
        self.print_summary(report)
        
        return report
    
    def print_summary(self, report):
        """Print evaluation summary to console"""
        print("\n" + "="*60)
        print("SIGNATURE FRAUD DETECTION - BATCH EVALUATION REPORT")
        print("="*60)
        
        # Dataset info
        dataset = report['dataset_info']
        print(f"\nDataset Information:")
        print(f"   - Total Images: {dataset['total_images']}")
        print(f"   - Forgery Images: {dataset['forgery_images']}")
        print(f"   - Genuine Images: {dataset['genuine_images']}")
        
        # Overall performance
        overall = report['overall_performance']
        if overall:
            print(f"\nOverall Performance:")
            print(f"   - Accuracy: {overall['accuracy']:.3f} ({overall['accuracy']*100:.1f}%)")
            print(f"   - Precision: {overall['precision']:.3f}")
            print(f"   - Recall: {overall['recall']:.3f}")
            print(f"   - F1-Score: {overall['f1_score']:.3f}")
            print(f"   - Valid Predictions: {overall['valid_predictions']}/{overall['total_samples']}")
            
            if 'confusion_matrix' in overall:
                cm = overall['confusion_matrix']
                print(f"\nConfusion Matrix:")
                print(f"   - True Negative (Genuine->Genuine): {cm[0][0] if len(cm) > 0 and len(cm[0]) > 0 else 0}")
                print(f"   - False Positive (Genuine->Forgery): {cm[0][1] if len(cm) > 0 and len(cm[0]) > 1 else 0}")
                print(f"   - False Negative (Forgery->Genuine): {cm[1][0] if len(cm) > 1 and len(cm[1]) > 0 else 0}")
                print(f"   - True Positive (Forgery->Forgery): {cm[1][1] if len(cm) > 1 and len(cm[1]) > 1 else 0}")
        
        # Per-class performance
        forgery = report['forgery_performance']
        genuine = report['genuine_performance']
        
        if forgery:
            print(f"\nForgery Detection Performance:")
            print(f"   - Accuracy: {forgery['accuracy']:.3f} ({forgery['accuracy']*100:.1f}%)")
            print(f"   - Valid Predictions: {forgery['valid_predictions']}/{forgery['total_samples']}")
        
        if genuine:
            print(f"\nGenuine Detection Performance:")
            print(f"   - Accuracy: {genuine['accuracy']:.3f} ({genuine['accuracy']*100:.1f}%)")
            print(f"   - Valid Predictions: {genuine['valid_predictions']}/{genuine['total_samples']}")
        
        # Model performance breakdown
        if self.results:
            valid_results = [r for r in self.results if r['predicted_label'] != -1 and r['individual_scores']]
            if valid_results:
                print(f"\nIndividual Model Performance:")
                model_names = ['cnn_a', 'cnn_b', 'rf', 'svm']
                for model in model_names:
                    scores = [r['individual_scores'].get(model, 0) for r in valid_results if model in r['individual_scores']]
                    if scores:
                        avg_score = np.mean(scores)
                        print(f"   - {model.upper()}: Average fraud probability = {avg_score:.3f}")
        
        print("\n" + "="*60)
        print(f"Detailed results saved to: evaluation_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        print("="*60)
    
    def save_results(self, report):
        """Save evaluation results to files"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Save JSON report
        json_filename = f"evaluation_report_{timestamp}.json"
        with open(json_filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        # Save CSV with detailed results
        csv_filename = f"evaluation_results_{timestamp}.csv"
        df = pd.DataFrame(report['detailed_results'])
        df.to_csv(csv_filename, index=False)
        
        # Save summary CSV
        summary_filename = f"evaluation_summary_{timestamp}.csv"
        summary_data = []
        
        if report['overall_performance']:
            summary_data.append({
                'Category': 'Overall',
                'Total_Images': report['overall_performance']['total_samples'],
                'Valid_Predictions': report['overall_performance']['valid_predictions'],
                'Accuracy': report['overall_performance']['accuracy'],
                'Precision': report['overall_performance']['precision'],
                'Recall': report['overall_performance']['recall'],
                'F1_Score': report['overall_performance']['f1_score']
            })
        
        if report['forgery_performance']:
            summary_data.append({
                'Category': 'Forgery',
                'Total_Images': report['forgery_performance']['total_samples'],
                'Valid_Predictions': report['forgery_performance']['valid_predictions'],
                'Accuracy': report['forgery_performance']['accuracy'],
                'Precision': report['forgery_performance'].get('precision', 0),
                'Recall': report['forgery_performance'].get('recall', 0),
                'F1_Score': report['forgery_performance'].get('f1_score', 0)
            })
        
        if report['genuine_performance']:
            summary_data.append({
                'Category': 'Genuine',
                'Total_Images': report['genuine_performance']['total_samples'],
                'Valid_Predictions': report['genuine_performance']['valid_predictions'],
                'Accuracy': report['genuine_performance']['accuracy'],
                'Precision': report['genuine_performance'].get('precision', 0),
                'Recall': report['genuine_performance'].get('recall', 0),
                'F1_Score': report['genuine_performance'].get('f1_score', 0)
            })
        
        if summary_data:
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_csv(summary_filename, index=False)
        
        logger.info(f"📄 Results saved:")
        logger.info(f"   • JSON Report: {json_filename}")
        logger.info(f"   • Detailed CSV: {csv_filename}")
        logger.info(f"   • Summary CSV: {summary_filename}")

def main():
    """Main function to run batch evaluation"""
    print("Signature Fraud Detection - Batch Evaluation")
    print("=" * 50)
    
    try:
        # Initialize evaluator
        evaluator = BatchEvaluator()
        
        # Check if test folders exist
        if not os.path.exists(evaluator.forgery_path):
            logger.error(f"❌ Forgery folder not found: {evaluator.forgery_path}")
            return
        
        if not os.path.exists(evaluator.genuine_path):
            logger.error(f"❌ Genuine folder not found: {evaluator.genuine_path}")
            return
        
        # Run evaluation
        report = evaluator.run_evaluation()
        
        print("\n✅ Evaluation completed successfully!")
        
    except Exception as e:
        logger.error(f"❌ Error during batch evaluation: {e}")
        raise

if __name__ == "__main__":
    main()
