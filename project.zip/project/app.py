# app.py
from flask import Flask, render_template, request, redirect
import numpy as np
import os
import pyttsx3
from werkzeug.utils import secure_filename
import threading
import logging

# Import email sender and ensemble predictor
from mailing import mailsend
from ensemble_predictor import EnsemblePredictor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = "static/uploads"

# Initialize ensemble predictor
try:
    ensemble_predictor = EnsemblePredictor()
    logger.info("✅ Ensemble predictor initialized successfully")
except Exception as e:
    logger.error(f"❌ Failed to initialize ensemble predictor: {e}")
    ensemble_predictor = None


def voiceplay(data):
    """Play voice feedback in a background thread"""
    def speak():
        engine = pyttsx3.init()
        engine.say(data)
        engine.runAndWait()
        engine.stop()

    threading.Thread(target=speak, daemon=True).start()


def predict_signature(path):
    """Enhanced prediction using ensemble approach"""
    if ensemble_predictor is None:
        logger.error("❌ Ensemble predictor not available, using fallback")
        return "ERROR: Model not loaded", 0.0
    
    try:
        # Use ensemble prediction with 75% confidence threshold
        prediction_type, confidence, individual_scores, is_high_confidence = ensemble_predictor.ensemble_predict(
            path, confidence_threshold=0.75
        )
        
        # Log individual model scores for debugging
        logger.info(f"Individual model scores: {individual_scores}")
        logger.info(f"Final prediction: {prediction_type} ({confidence}%)")
        logger.info(f"High confidence: {is_high_confidence}")
        
        return prediction_type, confidence, individual_scores, is_high_confidence
        
    except Exception as e:
        logger.error(f"❌ Error in prediction: {e}")
        return "ERROR IN PREDICTION", 0.0, {}, False


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "file" not in request.files or "email" not in request.form:
            return redirect(request.url)

        file = request.files["file"]
        receiver_email = request.form["email"]

        if file.filename == "" or receiver_email.strip() == "":
            return redirect(request.url)

        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)

            # Run enhanced ensemble prediction
            result = predict_signature(filepath)
            if len(result) == 4:
                typ, prob, individual_scores, is_high_confidence = result
            else:
                typ, prob = result[0], result[1]
                individual_scores, is_high_confidence = {}, False

            # Voice feedback (non-blocking)
            voiceplay(typ)
            voiceplay(f"Probability is {prob} percent")

            # Enhanced email logic - send email for any fraud detection above 60%
            if "FORGERY" in typ and prob >= 60:
                # Determine confidence level for email subject
                if prob >= 80:
                    subject = "🚨 HIGH CONFIDENCE Forgery Detected"
                    confidence_level = "HIGH CONFIDENCE"
                elif prob >= 70:
                    subject = "⚠️ MEDIUM CONFIDENCE Forgery Detected"
                    confidence_level = "MEDIUM CONFIDENCE"
                else:
                    subject = "⚠️ Potential Forgery Detected"
                    confidence_level = "MODERATE CONFIDENCE"
                
                model_details = "\n".join([f"{k.upper()}: {v:.1%}" for k, v in individual_scores.items()]) if individual_scores else "Individual model scores not available"
                
                body = f"""
🚨 FRAUD ALERT - {confidence_level} DETECTION 🚨

File: {filename}
Overall Fraud Probability: {prob}%
Classification: {typ}

Individual Model Analysis:
{model_details}

Timestamp: {logging.Formatter().formatTime(logging.LogRecord('', 0, '', 0, '', (), None))}

Please review this signature immediately for potential fraud.
"""
                try:
                    mailsend(receiver_email, subject, body)
                    logger.info(f"✅ Fraud alert email sent to {receiver_email} (Confidence: {prob}%)")
                    email_sent = True
                except Exception as e:
                    logger.error(f"❌ Failed to send email: {e}")
                    email_sent = False
            else:
                email_sent = False

            return render_template("result.html",
                                   file_path=filepath,
                                   result=typ,
                                   probability=prob,
                                   individual_scores=individual_scores,
                                   is_high_confidence=is_high_confidence,
                                   email_sent=email_sent if 'email_sent' in locals() else False)

    return render_template("index.html")


if __name__ == "__main__":
    if not os.path.exists("static/uploads"):
        os.makedirs("static/uploads")

    app.run(debug=True)
